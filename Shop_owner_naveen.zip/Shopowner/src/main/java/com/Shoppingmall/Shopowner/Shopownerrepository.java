package com.Shoppingmall.Shopowner;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Shopownerrepository extends JpaRepository<Shopowner, Integer>{

}
